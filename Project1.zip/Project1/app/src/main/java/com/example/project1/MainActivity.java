package com.example.project1;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Handler handler = new Handler();
    private Runnable timerRunnable;
    private GridLayout gridLayout;
    private int[][] positions;
    private TextView textTimer;
    private List<Integer> mines;
    private int counter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textTimer = findViewById(R.id.timer);
        positions = new int[12][10]; //assigning the rows and cols
        mines = new ArrayList<>();
        gridLayout = findViewById(R.id.gridLayout);

        startTimer();
        randomSpots();
        makeGrid();
    }

    private void startTimer() {
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                counter++;
                textTimer.setText("Timer: " + counter);
                handler.postDelayed(this, 1000); // Update every 1 second
            }
        };
        handler.post(timerRunnable);
    }
    private void randomSpots() {
        List<Integer> allVals = new ArrayList<>();
        for(int i = 0; i < 120; i++) allVals.add(i);

        //randomize the indices order
        Collections.shuffle(allVals);
        for(int i = 0; i < 3; i++) {
            int curr = allVals.get(i);
            mines.add(allVals.get(i));
            //need to mark the position of the mine
            positions[curr / 10][curr % 10] = 1;

        }
    }
    // Create the 12x10 grid of buttons and assign random values to the buttons
    private void makeGrid() {
        int vals = 0;
        for (int row = 0; row < 12; row++) {
            for (int col = 0; col < 10; col++) {
                Button button = new Button(this);
                final int rows = row, cols = col;
                button.setBackgroundColor(Color.GREEN);

                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (positions[rows][cols] == 1) {
                            Intent inte = new Intent(MainActivity.this, LandingPage.class);
                            inte.putExtra("TIMER_VALUE", counter);
                            inte.putExtra("MESSAGE_KEY", "You lose!");
                            startActivity(inte);
                        } else {
                            int near = countNear(rows, cols);
                            button.setText(String.valueOf(near));
                            button.setBackgroundColor(Color.WHITE);
                        }
                    }
                });

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.rowSpec = GridLayout.spec(row);
                params.columnSpec = GridLayout.spec(col);

                //change the button so that there are spaces
                params.setMargins(4, 4, 4, 4);
                params.width = 0;
                params.height = 0;
                params.rowSpec = GridLayout.spec(row, 1f);
                params.columnSpec = GridLayout.spec(col, 1f);

                button.setLayoutParams(params);

                // Add each button to the grid layout
                gridLayout.addView(button);
                vals++;
            }
        }
    }
    private int countNear(int r, int c) {
        int counter = 0;

        //run a double loop to check all adjacent positions
        for(int i = r - 1; i <= r + 1; i++) {
            for(int j = c - 1; j <= c + 1; j++) {
                if(positions[i][j] == 1) counter++;
            }
        }
        return counter;
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(timerRunnable); // Stop the timer when the activity is destroyed
    }
}
